This folder contains the notebooks for Sequential models.
The augmented and backtranslated data is created manually.
Backtranslation was done by translating each response to Finnish and then back to English.
Paraphrasing tools were used for augmentation.
This data augmentation applies to classical models as well.
