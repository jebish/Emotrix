Notebook folder contains all the notebooks used for this project.
The classical folder contains all the classical  models notebooks.
The sequential forlder contains all the sequential models notebooks.
