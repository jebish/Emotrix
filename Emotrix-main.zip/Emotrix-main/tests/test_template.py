def test_dummy():
    # We are automatically running tests in this directory on
    # package build. If no tests are present the build
    # will fail, so this test keeps it running.
    # You should delete this test and replace it with something
    # meaningful.
    pass